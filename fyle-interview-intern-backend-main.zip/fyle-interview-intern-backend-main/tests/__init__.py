from core.server import app
app.testing = True
